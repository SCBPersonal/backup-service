package com.hdfc.backup.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

@Data
@Configuration
@ConfigurationProperties(prefix = "yba")
@Validated
public class YbaProperties {

    //@NotBlank(message = "Database mapping JSON configuration is required")
    private String dbMappingJson;

    @Value("${yba.connection.timeout:30000}")
    private int connectionTimeout;

    @Value("${yba.read.timeout:60000}")
    private int readTimeout;

    @Value("${yba.retry.max-attempts:3}")
    private int maxRetryAttempts;
}
