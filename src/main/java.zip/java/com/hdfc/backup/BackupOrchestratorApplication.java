package com.hdfc.backup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackupOrchestratorApplication {
    public static void main(String[] args) {
        SpringApplication.run(BackupOrchestratorApplication.class, args);
    }
}
