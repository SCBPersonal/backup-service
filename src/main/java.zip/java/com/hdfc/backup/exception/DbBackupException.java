package com.hdfc.backup.exception;

public class DbBackupException extends RuntimeException{


    public DbBackupException(String message, Throwable cause) {
        super(message, cause);
    }

}
