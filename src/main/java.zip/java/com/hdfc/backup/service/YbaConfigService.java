package com.hdfc.backup.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdfc.backup.model.YbaDynamicConfig;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import com.hdfc.backup.config.YbaProperties;
import java.util.Map;

@Service
public class YbaConfigService {

    private final YbaProperties props;
    private final ObjectMapper mapper = new ObjectMapper();
    private Map<String, YbaDynamicConfig> configMap;

    public YbaConfigService(YbaProperties props) {
        this.props = props;
    }

    @PostConstruct
    public void init() throws Exception {
        configMap = mapper.readValue(
                props.getDbMappingJson(),
                new TypeReference<Map<String, YbaDynamicConfig>>() {}
        );
    }

    public YbaDynamicConfig resolve(String dbName) {
        return configMap.get(dbName);
    }
}
